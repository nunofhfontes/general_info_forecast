const { defineConfig } = require('@vue/cli-service')

module.exports = defineConfig({
  transpileDependencies: true,
  lintOnSave: false,
  // this was missing from the "strating project pack"
  configureWebpack: {
    output: {
      libraryTarget: 'system',
    },
  },
})
