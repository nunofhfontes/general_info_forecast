<template>
    <div class="header" id="myHeader">
        <h2 class="header-title">iProject</h2>
        <div class="poweredby">
            <span>Powered by Single-SPA</span>
            <!-- <img src="../assets/single_spa_icon_2.jpeg"> -->
        </div>
    </div>
</template>

<script setup>
import { ref } from 'vue'

const count = ref(0)
</script>

<!-- 
// #97A1AA; -->
<style>
.header {
  padding: 10px 16px;
  background: #20232a61;
  
  /* #ABB2B9; */
  color: #f1f1f1;

  justify-content: space-between;
  display: flex;
}

.header-title {
    align-self: center;
}

.poweredby {
    align-self: center;
}

/* Page content */
.content {
  padding: 16px;
}

/* The sticky class is added to the header with JS when it reaches its scroll position */
.sticky {
  position: fixed;
  top: 0;
  width: 100%
}

/* Add some top padding to the page content to prevent sudden quick movement (as the header gets a new position at the top of the page (position:fixed and top:0) */
.sticky + .content {
  padding-top: 102px;
}
</style>

