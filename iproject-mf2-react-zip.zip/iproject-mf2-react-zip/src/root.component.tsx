import { ProSidebarProvider } from 'react-pro-sidebar';
import App from './App';

export default function Root(props) {
  // return <section>{props.name} is mounted!</section>;
  return (
    <ProSidebarProvider>
      <App />
    </ProSidebarProvider>
  );
}



