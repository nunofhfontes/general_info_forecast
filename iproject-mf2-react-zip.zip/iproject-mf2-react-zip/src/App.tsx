import { Sidebar, Menu, MenuItem, SubMenu, useProSidebar } from 'react-pro-sidebar';
import react_icon from './assets/react_icon_1.png';
import vue_icon from './assets/vue_icon_3.png';
import svelte_icon from './assets/svelte_icon_1.png';

const App = () => {

    const { collapseSidebar } = useProSidebar();

    function handleSubmit(e) {
        e.preventDefault();
        console.log('You clicked.', e);

        window.singleSpaNavigate("/other");

        //window["singleSpaNavigate('/other')"];
    }

    const iconstyle = {

    }

    const reactIcon = (
        <img src={react_icon} alt="Logo" height={24} style={iconstyle}/>
    )
    const vueIcon = (
        <img src={vue_icon} alt="Logo" height={24} style={iconstyle}/>
    )
    const svelteIcon = (
        <img src={svelte_icon} alt="Logo" height={24} style={iconstyle}/>
    )

    return (
        <div style={{ display: 'flex', height: '100vh' }}>
            <Sidebar backgroundColor='#F2F3F4 '>
                <Menu>
                    <SubMenu label="Micro-Frontends Techs">
                        <MenuItem icon={reactIcon} onClick={() => window.singleSpaNavigate("/react")}> React </MenuItem>
                        <MenuItem icon={vueIcon} onClick={() => window.singleSpaNavigate("/vue")}> Vue </MenuItem>
                        <MenuItem icon={svelteIcon} onClick={() => window.singleSpaNavigate("/svelte")}> Svelte </MenuItem>
                    </SubMenu>
                    <SubMenu label="MF catalog">
                        <MenuItem onClick={() => window.singleSpaNavigate("/")}> Homebanking </MenuItem>
                        <MenuItem onClick={() => window.singleSpaNavigate("/")}> CRM </MenuItem>
                        <MenuItem onClick={() => window.singleSpaNavigate("/svelte")}> eCommerce </MenuItem>
                    </SubMenu>
                    <MenuItem> Documentation </MenuItem>
                    <MenuItem> Calendar </MenuItem>
                </Menu>
            </Sidebar>
            {/* <main>
                <button onClick={() => collapseSidebar()}>Collapse</button>
            </main> */}
        </div>
    );
  };
  
  export default App;