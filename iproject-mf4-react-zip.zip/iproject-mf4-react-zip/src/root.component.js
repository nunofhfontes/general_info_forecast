import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link,
  Routes
} from "react-router-dom";

import './App.css';

import logo from '../assets/react_logo_7.svg';
import react_background from '../assets/react_background_7.jpeg';
import react_icon from '../assets/react_icon_1.png';

/* export default function Root(props) {
  return <section>{props.name} is mounted!</section>;
} */

const imgWrapper = {
  display: "flex",
};

const imgstyle = {
  margin: "auto",
  /* padding: "10px",
  fontFamily: "Arial" */
};

const mainDiv = {
  /* color: '#6e7076',
  'background-color': '#fafafa', */
  
}

const title = {
  'text-align': 'center',
  color: '#61dafb'
}


export default function Root(props) {
  return (
    <Router>
      <div class="mainDiv" style={mainDiv}>
        
        <div className="logoWrapper">
          {/* <img src={logo} alt="Logo" height={250} width={250}/> */}
          <img src={react_background} alt="Logo" height={425} style={imgstyle}/>
        </div>
        <h1 style={title}>Micro-Frontends in React</h1>

        <div class="subtitle">A JavaScript library for building user interfaces</div>
        
        <div class="btn-row">
          <div class="react_button">
            <Link to="/react-web-components">Web Components</Link>
          </div>
          <div class="react_button">
            <Link to="/how-to">How To</Link>
          </div>
          <div class="react_button">
            <a href="https://reactjs.org/">React Doc</a>
          </div>
        </div>
      
        <Routes>
          <Route path="/react-web-components" element={<About/>} />
          <Route path="/users" element={<Users/>} />
          <Route path="/" element={<Home/>} />
        </Routes>
      </div>
    </Router>
  );
}

function Home() {
  return <h2>Home</h2>;
}

function About() {
  return <h2>About</h2>;
}

function Users() {
  return <h2>Users</h2>;
}
