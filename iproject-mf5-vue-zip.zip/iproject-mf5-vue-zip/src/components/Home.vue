<template>
    <div class="main-vue-mf" id="">
        <div class="vue-img">
            <img class="img-style" src="../assets/vue_background_14.jpeg">
        </div>
        <h1 class="vue-header-title">Micro-Frontends in Vue</h1>
    </div>
</template>

<script setup>
import { ref } from 'vue'

const count = ref(0)
</script>

<!-- 
// #97A1AA; -->
<style>
.img-style {
    width: 100%;
}


.header {
  padding: 10px 16px;
  background: #20232a61;
  
  /* #ABB2B9; */
  color: #f1f1f1;

  justify-content: space-between;
  display: flex;
}

.header-title {
    align-self: center;
}

.poweredby {
    align-self: center;
}

/* Page content */
.content {
  padding: 16px;
}

/* The sticky class is added to the header with JS when it reaches its scroll position */
.sticky {
  position: fixed;
  top: 0;
  width: 100%
}

/* Add some top padding to the page content to prevent sudden quick movement (as the header gets a new position at the top of the page (position:fixed and top:0) */
.sticky + .content {
  padding-top: 102px;
}
</style>

